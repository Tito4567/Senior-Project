package com.example.tito.profile1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;

public class MainActivity extends AppCompatActivity {

    HdoubleTP serv = new HdoubleTP(""," ");
    String send = null;
    final ImageAdapter t = new ImageAdapter(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       /* getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setIcon(R.drawable.p);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        getSupportActionBar().setTitle("Testing title");*/
        getSupportActionBar().hide();

        GridView gridview = (GridView) findViewById(R.id.gridview);
        gridview.setAdapter(t);


        gridview.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
                t.getImage(position);
                send = Integer.toString(t.getImage(position));
                activityCall();
            }
        });
    }

    public void activityCall() {
        Intent t = new Intent(this, PostFull.class);
        t.putExtra("callingActivity", send);
        startActivity(t);
    }
}