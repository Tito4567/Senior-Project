package com.example.tito.profile1;

import android.content.Intent;
import android.support.v7.widget.Toolbar;
import android.support.annotation.IdRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Adapter.*;
import android.widget.Toast;

import com.roughike.bottombar.BottomBar;
import com.roughike.bottombar.OnMenuTabSelectedListener;


public class MainActivity extends AppCompatActivity
{

    Toolbar t;
    BottomBar bar;
    String send = null;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setIcon(R.drawable.p);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        getSupportActionBar().setTitle("Testing title");


        GridView gridview = (GridView) findViewById(R.id.gridview);
        gridview.setAdapter(new ImageAdapter(this));

        gridview.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            public void onItemClick(AdapterView<?> parent, View v, int position, long id)
            {
                Toast.makeText(MainActivity.this, "This is it " + position, Toast.LENGTH_SHORT).show();
                activityCall();

                send = Integer.toString(position);

            }
        });


        /*bar = BottomBar.attach(this, savedInstanceState);
        bar.setItemsFromMenu(R.menu.menu_main, new OnMenuTabSelectedListener() {
            @Override
            public void onMenuItemSelected(@IdRes int menuItemId)
            {
                //non
            }
        });*/
    }

    public void activityCall()
    {
        Intent t = new Intent(this, PostFull.class);
        t.putExtra("callingActivity", send);
        startActivity(t);

    }



}
