package com.example.tito.profile1;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;

/**
 * Created by Tito on 3/6/2017.
 */

public class PostFull extends Activity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
       /* ImageView g = (ImageView) findViewById(R.id.pic);
        g.setImageResource(R.drawable.crying);*/
        setContentView(R.layout.second_layout);
       // Intent called = getIntent();
       // String recieved = called.getExtras().getString("callingActivity");
        posting();
    }


    public void posting()
    {
        ImageView g = (ImageView) findViewById(R.id.pic);
        g.setImageResource(R.drawable.post);

        Intent getMessage = getIntent();
       // if(null != getMessage.getExtras().getString("callingActivity");){}
    }

}
